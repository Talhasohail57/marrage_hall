using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace marrage_hall.Pages
{
    public class teamModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
