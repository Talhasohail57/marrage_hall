using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace marrage_hall.Pages
{
    public class aboutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
