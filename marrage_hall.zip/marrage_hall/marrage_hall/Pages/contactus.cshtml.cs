using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace marrage_hall.Pages
{
    public class contactusModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
