using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace marrage_hall.Pages
{
    public class galleryModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
