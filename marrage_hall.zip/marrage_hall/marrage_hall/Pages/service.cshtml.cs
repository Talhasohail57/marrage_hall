using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace marrage_hall.Pages
{
    public class serviceModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
